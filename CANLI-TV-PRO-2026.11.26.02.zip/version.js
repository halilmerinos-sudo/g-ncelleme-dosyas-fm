window.APP_UPDATE = {
  "version": "2026.11.26.02",
  "url": "index.html",
  "notes": "Günün ayeti ve hadisi program açılışında günde bir kez, 20 saniye gösterilir; aynı gün tekrar çıkmaz.",
  "date": "2026-11-26"
};
